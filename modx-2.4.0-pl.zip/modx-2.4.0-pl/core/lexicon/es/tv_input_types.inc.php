<?php
/**
 * TV Input Types English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['autotag'] = 'Auto-Etiqueta';
$_lang['text'] = 'Texto';
$_lang['textarea'] = 'Área de texto';
$_lang['textareamini'] = 'Area de Texto (Mini)';
$_lang['richtext'] = 'Texto Formateado';
$_lang['dropdown'] = 'Lista Desplegable';
$_lang['listbox'] = 'Lista (Sel. Sencilla)';
$_lang['listbox-multiple'] = 'Lista (Sel. Múltiple)';
$_lang['list-multiple-legacy'] = 'Lista múltiple heredada';
$_lang['option'] = 'Botón circular';
$_lang['checkbox'] = 'Checkbox';
$_lang['image'] = 'Imagen';
$_lang['file'] = 'Archivo';
$_lang['url'] = 'URL';
$_lang['email'] = 'Email';
$_lang['number'] = 'Número';
$_lang['date'] = 'Fecha';
$_lang['tag'] = 'Etiqueta';